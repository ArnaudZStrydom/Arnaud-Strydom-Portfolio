#include "BreadthFirstIterator.h"

BreadthFirstIterator::BreadthFirstIterator(const std::vector<FarmUnit*>& farms) : farms(farms), current(nullptr) {
    if (!farms.empty()) {
        farmQueue.push(farms[0]);
        current = farms[0];
    }
}

FarmUnit* BreadthFirstIterator::firstFarm() {
    if (!farms.empty()) {
        while (!farmQueue.empty()) {
            farmQueue.pop();
        }
        farmQueue.push(farms[0]);
        current = farms[0];
    }
    return current;
}

void BreadthFirstIterator::next() {
    if (!farmQueue.empty()) {
        FarmUnit* front = farmQueue.front();
        farmQueue.pop();

        std::vector<FarmUnit*> adjacentFarms = front->getAdjacentFarms();
        for (auto farm : adjacentFarms) {
            farmQueue.push(farm);
        }

        if (!farmQueue.empty()) {
            current = farmQueue.front();
        }
    }
}

bool BreadthFirstIterator::isDone() {
    return farmQueue.empty();
}

FarmUnit* BreadthFirstIterator::currentFarm() {
    return current;
}