#include "CropFieldDecorator.h"

CropFieldDecorator::CropFieldDecorator(CropField* field)
    : CropField(field->getCropType(), field->getTotalCapacity(), field->getSoilStateName()), wrappedField(field) {}

int CropFieldDecorator::getTotalCapacity() {
    return wrappedField->getTotalCapacity();
}

std::string CropFieldDecorator::getCropType() {
    return wrappedField->getCropType();
}

std::string CropFieldDecorator::getSoilStateName() {
    return wrappedField->getSoilStateName();
}