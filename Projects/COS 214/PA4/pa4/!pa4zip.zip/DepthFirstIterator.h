#ifndef DEPTHFIRSTITERATOR_H
#define DEPTHFIRSTITERATOR_H

#include "FarmIterator.h"
#include <stack>
#include <vector>

class DepthFirstIterator : public FarmIterator {
private:
    std::stack<FarmUnit*> farmStack;
    std::vector<FarmUnit*> farms;
    FarmUnit* current;

public:
    DepthFirstIterator(const std::vector<FarmUnit*>& farms);

    FarmUnit* firstFarm() override;
    void next() override;
    bool isDone() override;
    FarmUnit* currentFarm() override;
};

#endif // DEPTHFIRSTITERATOR_H