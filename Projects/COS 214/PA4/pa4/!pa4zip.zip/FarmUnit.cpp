#include "FarmUnit.h"

int FarmUnit::getTotalCapacity() {
	// TODO - implement FarmUnit::getTotalCapacity
	throw "Not yet implemented";
}

string FarmUnit::getCropType() {
	// TODO - implement FarmUnit::getCropType
	throw "Not yet implemented";
}

string FarmUnit::getSoilStateName() {
	// TODO - implement FarmUnit::getSoilStateName
	throw "Not yet implemented";
}
