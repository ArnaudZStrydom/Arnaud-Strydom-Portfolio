#ifndef TRUCK_H
#define TRUCK_H

#include "FertilizerTruck.h"
#include "DeliveryTruck.h"
#include "FarmUnit.h"

class Truck : public FertilizerTruck, public DeliveryTruck {
public:
    bool isAvailable;

    Truck() : isAvailable(true) {}

    virtual void startEngine() = 0; // Pure virtual method

    void callTruck(FarmUnit* farmUnit); // Change to pointer
};

#endif // TRUCK_H