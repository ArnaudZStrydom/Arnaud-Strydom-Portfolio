#ifndef FRUITFULSOIL_H
#define FRUITFULSOIL_H

#include "SoilState.h"
#include "FloodedSoil.h" // Assuming FloodedSoil is another concrete class
#include <string>

class FruitfulSoil : public SoilState {
public:
    int harvestCrops(int currentAmount) override;
    SoilState* rain() override;
	std::string getName() const;
    std::string getName() override;
};

#endif // FRUITFULSOIL_H