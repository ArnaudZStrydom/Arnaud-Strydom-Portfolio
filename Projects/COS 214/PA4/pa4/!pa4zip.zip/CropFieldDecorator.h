#ifndef CROPFIELDDECORATOR_H
#define CROPFIELDDECORATOR_H

#include "CropField.h"

class CropFieldDecorator : public CropField {
protected:
    CropField* wrappedField;

public:
    CropFieldDecorator(CropField* field);

    int getTotalCapacity() override;
    std::string getCropType() override;
    std::string getSoilStateName() override;
    virtual void increaseProduction() = 0; // Pure virtual method
};

#endif // CROPFIELDDECORATOR_H