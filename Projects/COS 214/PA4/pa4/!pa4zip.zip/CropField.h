#ifndef CROPFIELD_H
#define CROPFIELD_H

#include "FarmUnit.h"
#include "FruitfulSoil.h"
#include <vector>
#include <string>

class CropField : public FarmUnit {
private:
    std::string cropType;
    int totalCapacity;
    std::string soilStateName;
    std::vector<FarmUnit*> adjacentFarms;

public:
    CropField(const std::string& cropType, int totalCapacity, const std::string& soilStateName);

    int getTotalCapacity() override;
    std::string getCropType() override;
    std::string getSoilStateName() override;
    std::vector<FarmUnit*> getAdjacentFarms() override;
    void setSoilState(const FruitfulSoil& newSoilState); // Modify this method
};

#endif // CROPFIELD_H