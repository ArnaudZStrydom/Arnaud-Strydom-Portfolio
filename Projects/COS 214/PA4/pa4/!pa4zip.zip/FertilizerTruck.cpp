#include "FertilizerTruck.h"
#include <iostream>

void FertilizerTruck::startEngine() {
    std::cout << "Engine started." << std::endl;
}

void FertilizerTruck::callTruck(FarmUnit* farmUnit) { // Change to pointer
    std::cout << "Delivering fertilizer to farm unit: " << farmUnit->getCropType() << std::endl; // Use getCropType() as an example
}