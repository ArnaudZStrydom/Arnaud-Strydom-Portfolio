#include "FertilizedField.h"

FertilizedField::FertilizedField(CropField* field)
    : CropFieldDecorator(field) {}

void FertilizedField::increaseProduction() {
    wrappedField->setSoilState(FruitfulSoil());
}