#include "ExtraBarnField.h"

ExtraBarnField::ExtraBarnField(CropField* field, int extraCapacity)
    : CropFieldDecorator(field), extraCapacity(extraCapacity) {}

int ExtraBarnField::getTotalCapacity() {
    return wrappedField->getTotalCapacity() + extraCapacity;
}

int ExtraBarnField::getLeftoverCapacity() {
    // Assuming getLeftoverCapacity() is calculated as the remaining capacity
    // after some operations, here we just return the extra capacity for simplicity.
    return extraCapacity;
}