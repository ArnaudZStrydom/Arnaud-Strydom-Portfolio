#include "DrySoil.h"

int DrySoil::harvestCrops(int currentAmount) {
    return currentAmount; // No yield multiplier
}

SoilState* DrySoil::rain() {
    // Example condition: 50% chance to transition to FruitfulSoil
    if (rand() % 2 == 0) {
        return new FruitfulSoil();
    } else {
        return this; // Remain in DrySoil state
    }
}

std::string DrySoil::getName() {
    return "Dry";
}