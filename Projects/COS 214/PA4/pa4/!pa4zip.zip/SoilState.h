#ifndef SOILSTATE_H
#define SOILSTATE_H

#include <string>

class SoilState {
public:
    virtual ~SoilState() = default;

    virtual int harvestCrops(int currentAmount) = 0;
    virtual SoilState* rain() = 0;
    virtual std::string getName() = 0;
};

#endif // SOILSTATE_H