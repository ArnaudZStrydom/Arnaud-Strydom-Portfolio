#ifndef FLOODEDSOIL_H
#define FLOODEDSOIL_H

#include "SoilState.h"
#include <string>

class FloodedSoil : public SoilState {
public:
    int harvestCrops(int currentAmount) override;
    SoilState* rain() override;
    std::string getName() override;
};

#endif // FLOODEDSOIL_H