#include "DepthFirstIterator.h"

DepthFirstIterator::DepthFirstIterator(const std::vector<FarmUnit*>& farms) : farms(farms), current(nullptr) {
    if (!farms.empty()) {
        farmStack.push(farms[0]);
        current = farms[0];
    }
}

FarmUnit* DepthFirstIterator::firstFarm() {
    if (!farms.empty()) {
        while (!farmStack.empty()) {
            farmStack.pop();
        }
        farmStack.push(farms[0]);
        current = farms[0];
    }
    return current;
}

void DepthFirstIterator::next() {
    if (!farmStack.empty()) {
        FarmUnit* top = farmStack.top();
        farmStack.pop();

        std::vector<FarmUnit*> adjacentFarms = top->getAdjacentFarms();
        for (auto it = adjacentFarms.rbegin(); it != adjacentFarms.rend(); ++it) {
            farmStack.push(*it);
        }

        if (!farmStack.empty()) {
            current = farmStack.top();
        }
    }
}

bool DepthFirstIterator::isDone() {
    return farmStack.empty();
}

FarmUnit* DepthFirstIterator::currentFarm() {
    return current;
}