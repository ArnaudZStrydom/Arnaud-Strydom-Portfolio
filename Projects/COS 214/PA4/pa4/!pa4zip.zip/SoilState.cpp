#include "SoilState.h"

int SoilState::harvestCrops(int currentAmount) {
	// TODO - implement SoilState::harvestCrops
	throw "Not yet implemented";
}

SoilState* SoilState::rain() {
    // Implementation of rain
    return nullptr; // Placeholder
}

std::string SoilState::getName() {
    // Implementation of getName
    return "SoilState"; // Placeholder
}
