#include "FloodedSoil.h"

int FloodedSoil::harvestCrops(int currentAmount) {
    return 0; // No yield possible
}

SoilState* FloodedSoil::rain() {
    return this; // Remain in FloodedSoil state
}

std::string FloodedSoil::getName() {
    return "Flooded";
}