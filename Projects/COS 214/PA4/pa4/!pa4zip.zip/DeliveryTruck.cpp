#include "DeliveryTruck.h"
#include <iostream>

void DeliveryTruck::startEngine() {
    std::cout << "Engine started." << std::endl;
}

void DeliveryTruck::callTruck(FarmUnit* farmUnit) { // Change to pointer
    std::cout << "Collecting crops from farm unit: " << farmUnit->getCropType() << std::endl; // Use getCropType() as an example
}