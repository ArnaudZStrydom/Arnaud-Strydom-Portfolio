#include "Barn.h"

Barn::Barn(int capacity, const std::string& cropType, const std::string& soilStateName)
    : capacity(capacity), cropType(cropType), soilStateName(soilStateName) {}

int Barn::getTotalCapacity() {
    return capacity;
}

std::string Barn::getCropType() {
    return cropType;
}

std::string Barn::getSoilStateName() {
    return soilStateName;
}