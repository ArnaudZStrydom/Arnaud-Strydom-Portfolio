#include <iostream>
#include "CropField.h"
#include "BreadthFirstIterator.h"
#include "DepthFirstIterator.h"

void t2(){
    CropField wheatField("Wheat", 1000, "Fertile"); // Change to match the available constructor
    std::cout << "Total Capacity: " << wheatField.getTotalCapacity() << std::endl;
    std::cout << "Crop Type: " << wheatField.getCropType() << std::endl;
    std::cout << "Soil State: " << wheatField.getSoilStateName() << std::endl;
}

void t1(){
    CropField wheatField("Wheat", 1000, "Fertile");
    std::vector<FarmUnit*> farms = { &wheatField };
    BreadthFirstIterator bfIterator(farms);
    DepthFirstIterator dfIterator(farms);
    std::cout << "Breadth-First Iterator:" << std::endl;
    for (FarmUnit* farm = bfIterator.firstFarm(); !bfIterator.isDone(); bfIterator.next()) {
        std::cout << farm->getCropType() << std::endl;
    }
    std::cout << "Depth-First Iterator:" << std::endl;
    for (FarmUnit* farm = dfIterator.firstFarm(); !dfIterator.isDone(); dfIterator.next()) {
        std::cout << farm->getCropType() << std::endl;
    }
}

int main() {
    t1();
    t2();
    return 0;
}