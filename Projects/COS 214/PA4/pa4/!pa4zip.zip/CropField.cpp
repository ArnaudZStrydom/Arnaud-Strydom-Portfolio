#include "CropField.h"
#include "FruitfulSoil.h"

CropField::CropField(const std::string& cropType, int totalCapacity, const std::string& soilStateName)
    : cropType(cropType), totalCapacity(totalCapacity), soilStateName(soilStateName) {}

int CropField::getTotalCapacity() {
    return totalCapacity;
}

std::string CropField::getCropType() {
    return cropType;
}

std::string CropField::getSoilStateName() {
    return soilStateName;
}

std::vector<FarmUnit*> CropField::getAdjacentFarms() {
    return adjacentFarms;
}

void CropField::setSoilState(const FruitfulSoil& newSoilState) {
    soilStateName = newSoilState.getName();
}