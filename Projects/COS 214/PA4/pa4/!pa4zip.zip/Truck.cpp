#include "Truck.h"
#include <iostream>

void Truck::callTruck(FarmUnit* farmUnit) { // Change to pointer
    std::cout << "Delivering to farm unit with crop type: " << farmUnit->getCropType() << std::endl; // Example usage
}