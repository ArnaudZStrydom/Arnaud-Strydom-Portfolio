#ifndef FERTILIZEDFIELD_H
#define FERTILIZEDFIELD_H

#include "CropFieldDecorator.h"
#include "FruitfulSoil.h"

class FertilizedField : public CropFieldDecorator {
public:
    FertilizedField(CropField* field);

    void increaseProduction() override;
};

#endif // FERTILIZEDFIELD_H