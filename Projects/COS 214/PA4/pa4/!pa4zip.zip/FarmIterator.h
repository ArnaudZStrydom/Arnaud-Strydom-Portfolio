#ifndef FARMITERATOR_H
#define FARMITERATOR_H

#include "FarmUnit.h"

class FarmIterator {
public:
    virtual ~FarmIterator() = default;
    virtual FarmUnit* firstFarm() = 0;
    virtual void next() = 0;
    virtual bool isDone() = 0;
    virtual FarmUnit* currentFarm() = 0;
};

#endif // FARMITERATOR_H