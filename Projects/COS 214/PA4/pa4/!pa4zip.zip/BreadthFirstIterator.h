#ifndef BREADTHFIRSTITERATOR_H
#define BREADTHFIRSTITERATOR_H

#include "FarmIterator.h"
#include <queue>
#include <vector>

class BreadthFirstIterator : public FarmIterator {
private:
    std::queue<FarmUnit*> farmQueue;
    std::vector<FarmUnit*> farms;
    FarmUnit* current;

public:
    BreadthFirstIterator(const std::vector<FarmUnit*>& farms);

    FarmUnit* firstFarm() override;
    void next() override;
    bool isDone() override;
    FarmUnit* currentFarm() override;
};

#endif // BREADTHFIRSTITERATOR_H