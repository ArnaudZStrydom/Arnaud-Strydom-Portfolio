#ifndef DELIVERYTRUCK_H
#define DELIVERYTRUCK_H

#include "FarmUnit.h"

class DeliveryTruck {
public:
    void startEngine();
    void callTruck(FarmUnit* farmUnit); // Change to pointer
};

#endif // DELIVERYTRUCK_H