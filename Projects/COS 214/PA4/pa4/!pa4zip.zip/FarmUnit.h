#ifndef FARMUNIT_H
#define FARMUNIT_H

#include <string>
#include <vector>
using namespace std;

class FarmUnit {
public:
    virtual ~FarmUnit() = default;
    virtual int getTotalCapacity() = 0;
    virtual string getCropType() = 0;
    virtual string getSoilStateName() = 0;
    virtual vector<FarmUnit*> getAdjacentFarms() = 0; // Add this method
};

#endif // FARMUNIT_H