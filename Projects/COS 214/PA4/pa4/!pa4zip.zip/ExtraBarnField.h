#ifndef EXTRABARNFIELD_H
#define EXTRABARNFIELD_H

#include "CropFieldDecorator.h"

class ExtraBarnField : public CropFieldDecorator {
private:
    int extraCapacity;

public:
    ExtraBarnField(CropField* field, int extraCapacity);

    int getTotalCapacity() override;
    int getLeftoverCapacity();
};

#endif // EXTRABARNFIELD_H