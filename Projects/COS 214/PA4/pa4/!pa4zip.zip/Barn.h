#ifndef BARN_H
#define BARN_H

#include "FarmUnit.h"
#include <string>

class Barn : public FarmUnit {
private:
    int capacity;
    std::string cropType;
    std::string soilStateName;

public:
    Barn(int capacity, const std::string& cropType, const std::string& soilStateName);

    int getTotalCapacity() override;
    std::string getCropType() override;
    std::string getSoilStateName() override;
};

#endif // BARN_H
