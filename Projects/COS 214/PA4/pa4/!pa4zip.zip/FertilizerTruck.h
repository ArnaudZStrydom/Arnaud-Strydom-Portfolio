#ifndef FERTILIZERTRUCK_H
#define FERTILIZERTRUCK_H

#include "FarmUnit.h"

class FertilizerTruck {
public:
    void startEngine();
    void callTruck(FarmUnit* farmUnit); // Change to pointer
};

#endif // FERTILIZERTRUCK_H