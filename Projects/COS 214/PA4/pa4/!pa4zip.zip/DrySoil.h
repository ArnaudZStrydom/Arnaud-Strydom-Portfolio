#ifndef DRYSOIL_H
#define DRYSOIL_H

#include "SoilState.h"
#include "FruitfulSoil.h" // Assuming FruitfulSoil is another concrete class

class DrySoil : public SoilState {
public:
    int harvestCrops(int currentAmount) override;
    SoilState* rain() override;
    std::string getName() override;
};

#endif // DRYSOIL_H