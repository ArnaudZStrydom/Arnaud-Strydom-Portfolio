#include "FruitfulSoil.h"

int FruitfulSoil::harvestCrops(int currentAmount) {
    return currentAmount * 3; // x3 yield
}

SoilState* FruitfulSoil::rain() {
    // Example condition: 50% chance to transition to FloodedSoil
    if (rand() % 2 == 0) {
        return new FloodedSoil();
    } else {
        return this; // Remain in FruitfulSoil state
    }
}

std::string FruitfulSoil::getName() {
    return "Fruitful";
}

std::string FruitfulSoil::getName() const {
    return "FruitfulSoil"; // Example implementation
}