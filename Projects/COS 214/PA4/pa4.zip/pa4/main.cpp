#include <iostream>
#include <vector>
#include "FarmUnit.h"
#include "CropField.h"
#include "Barn.h"
#include "FertilizerTruck.h"
#include "DeliveryTruck.h"
#include "FertilizedField.h"
#include "ExtraBarnField.h"
#include "FarmTraverser.h"
#include "SoilState.h"
#include "DrySoil.h"


int main() {
    // Step 1: Create the basic farm structure
    CropField* wheatField = new CropField("Wheat", 100,"Wheatfield1");
    CropField* cornField = new CropField("Corn", 80 ,"cornField1");
    Barn* mainBarn = new Barn(200,"barn of big things");

    // Print initial capacities
    std::cout << "Initial Capacities:\n";
    std::cout << "Wheat Field Capacity: " << wheatField->getTotalCapacity() << std::endl;
    std::cout << "Corn Field Capacity: " << cornField->getTotalCapacity() << std::endl;
    std::cout << "Main Barn Capacity: " << mainBarn->getTotalCapacity() << std::endl;

    // Step 2: Decorate crop fields
    CropField* fertilizedWheatField = new FertilizedField(wheatField);
    CropField* barnedCornField = new ExtraBarnField(cornField, 50);
    CropField* superField = new ExtraBarnField(fertilizedWheatField, 30);  // Multiple decorators

    // Print capacities after decoration
    std::cout << "\nCapacities After Decoration:\n";
    std::cout << "Super Wheat Field Capacity: " << superField->getTotalCapacity() << std::endl;
    std::cout << "Super Wheat Field Leftover Capacity: " << superField->getLeftoverCapacity() << std::endl;
    std::cout << "Barned Corn Field Capacity: " << barnedCornField->getTotalCapacity() << std::endl;
    std::cout << "Barned Corn Field Leftover Capacity: " << barnedCornField->getLeftoverCapacity() << std::endl;

    // Step 3: Simulate trucks logistics
    FertilizerTruck* fertilizerTruck = new FertilizerTruck();
    DeliveryTruck* deliveryTruck = new DeliveryTruck();

    std::vector<Truck*> trucks;
    trucks.push_back(fertilizerTruck);
    trucks.push_back(deliveryTruck);

    std::cout << "\nList of Trucks Available:\n";
    for (auto& truck : trucks) {
        std::cout << truck->getType() << std::endl;
    }

    // Step 4: Simulate various conditions and trigger truck operations
    std::cout << "\nSimulating dry soil condition for wheat field...\n";
    SoilState* drysoil1 = new DrySoil();
    wheatField->setSoilState(drysoil1);
    for (auto& truck : trucks) {
        truck->performOperation(wheatField);  // Should trigger fertilizer delivery
    }

    std::cout << "\nSimulating near full storage for corn field...\n";
    barnedCornField->storeCrops(70);  // Assume corn field is near full capacity
    for (auto& truck : trucks) {
        truck->performOperation(barnedCornField);  // Should trigger crop collection
    }

    // Step 5: Traverse the farm with both strategies

    // Create a simple farm structure
    std::vector<FarmUnit*> farmUnits = {wheatField, cornField, mainBarn};

    // Breadth-First Traversal
    std::cout << "\nBreadth-First Traversal of the farm:\n";
    FarmIterator* bfsIterator = new BreadthFirstIterator(wheatField); // Starting from wheatField
    for (bfsIterator->firstFarm(); !bfsIterator->isDone(); bfsIterator->next()) {
        FarmUnit* currentFarm = bfsIterator->currentFarm();
        if (currentFarm) {
            std::cout << "Visiting: " << currentFarm->getName() << ", Total Capacity: " << currentFarm->getTotalCapacity() << std::endl;
        }
    }
    delete bfsIterator;

    // Depth-First Traversal
    std::cout << "\nDepth-First Traversal of the farm:\n";
    FarmIterator* dfsIterator = new DepthFirstIterator(cornField); // Starting from cornField
    for (dfsIterator->firstFarm(); !dfsIterator->isDone(); dfsIterator->next()) {
        FarmUnit* currentFarm = dfsIterator->currentFarm();
        if (currentFarm) {
            std::cout << "Visiting: " << currentFarm->getName() << ", Total Capacity: " << currentFarm->getTotalCapacity() << std::endl;
        }
    }
    delete dfsIterator;

    // Step 6: Test edge cases
    std::cout << "\nTesting edge cases:\n";

    // Empty farm traversal
    CropField* emptyField = new CropField("EmptyField", 0 ,"Empty");
    FarmIterator* emptyIterator = new BreadthFirstIterator(emptyField);
    if (emptyIterator->isDone()) {
        std::cout << "Traversal correctly identifies an empty farm.\n";
    } else {
        std::cout << "Empty farm traversal failed.\n";
    }
    delete emptyIterator;
    delete emptyField;

    // Test without applying any trucks
    std::cout << "\nTesting without truck operations:\n";
    cornField->setSoilState(new DrySoil());
    std::cout << "Corn Field Soil State: " << cornField->getSoilStateName() << std::endl;

    // Step 7: Clean up
    delete superField;         // Deleting the decorated field will delete the original as well
    delete barnedCornField;    // Deleting the decorated field will delete the original as well
    for (auto& truck : trucks) {
        delete truck;
    }

    return 0;
}
