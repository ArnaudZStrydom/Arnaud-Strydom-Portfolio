#include "Farm.h"
#include <algorithm>

int Farm::getTotalCapacity() {
    int totalCapacity = 0;
    for (FarmUnit* unit : farmUnits) {
        totalCapacity += unit->getTotalCapacity();
    }
    return totalCapacity;
}

void Farm::addFarmUnit(FarmUnit* unit) {
    farmUnits.push_back(unit);
}

void Farm::removeFarmUnit(FarmUnit* unit) {
    farmUnits.erase(std::remove(farmUnits.begin(), farmUnits.end(), unit), farmUnits.end());
}

std::string Farm::getCropType() {
    return ""; // General farm doesn't have a specific crop type
}

std::string Farm::getSoilStateName() {
    return "N/A"; // General farm doesn't have a specific soil state
}