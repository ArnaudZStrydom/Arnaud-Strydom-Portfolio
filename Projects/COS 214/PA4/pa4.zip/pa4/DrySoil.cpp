#include "DrySoil.h"
#include "CropField.h"
#include "FruitfulSoil.h"  // Include for state transition


std::string DrySoil::getName() const
{
    return "Dry";
}

int DrySoil::harvestCrops() const {
    return 1;  // Minimal yield
}

void DrySoil::rain(CropField* field) {
    field->setSoilState(new FruitfulSoil());  // Transition to FruitfulSoil
}
