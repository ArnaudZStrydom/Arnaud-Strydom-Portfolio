#ifndef FARM_H
#define FARM_H

#include <vector>
#include "FarmUnit.h"

class Farm : public FarmUnit {
private:
    std::vector<FarmUnit*> farmUnits;

public:
    int getTotalCapacity() override;
    void addFarmUnit(FarmUnit* unit);
    void removeFarmUnit(FarmUnit* unit);
    std::string getCropType() override;
    std::string getSoilStateName() override;
};

#endif // FARM_H