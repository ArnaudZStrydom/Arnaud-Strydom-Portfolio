//Have your includes/requires here


const allowedFiles = ['/']; //A list of allowed files
var messages = {'messages' : [{'user' : 'Chitter Help', 'message' : 'Welcome to Chitter! Start Chitting Today!'}]}; //An object with a message array

console.log('Starting Server');

//Create your server here, listening on port 8085

//The callback should check if the method is GET or POST,
//send back files, send back the messages object,
//and store messages sent via POST

//console.log('Listening for connections');


//Get the POST parameters by splitting them on & and =
//You can create a function here that returns an object with all
//keys and values

//Good luck!
