<?php
include 'header.php';
?>
<!DOCTYPE html>
<html>

<head>
    <link rel="stylesheet" href="css/agents.css">
</head>
    <div id="flex-container">

    </div>

    <div class="loader">
      <img src="img/loader.gif" class="loader" alt="Loading...">
    </div>

    <div class="allagents">
      <!-- Agents will be dynamically added here -->
  </div>
  
  <script src="agents.js"></script>
</body>
</html>

<?php
include 'footer.php';
?>