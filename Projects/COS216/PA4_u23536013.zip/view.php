<?php
include 'header.php';
?>
<!DOCTYPE html>
<html>

<head>
    <link rel="stylesheet" href="css/view.css">
</head>
    <div id="flex-container">
      
  </div>

    <div class="loader">
      <img src="img/loader.gif" class="loader" alt="Loading...">
  </div>



  <div class="flex-container1">
    <div id = "HouseView-container" class="HouseView-container">
      <!-- Placeholder for carosel details -->

    </div>
  </div>
        
        <div class="allinfo">
            <div class="singleinfo">
                <div class="details">
                    <!-- Placeholder for listing details -->
                </div>
            </div>
        </div>
   



    <script src="View.js"></script>
</body>
</html>


<?php
include 'footer.php';
?>
