<?php
include 'header.php';
?>
<!DOCTYPE html>
<html>

<head>
    <link rel="stylesheet" href="css/favourites.css">
</head>


<div id="flex-container">
  
</div>

<div class="loader">
  <img src="img/loader.gif" class="loader" alt="Loading...">
</div>

<div class="alllistings">

</div>


<script src ="favourites.js"></script>
</body>
</html>

<?php
include 'footer.php';
?>