#include "DeviceObserver.h"

DeviceObserver::DeviceObserver(SmartDevice* dev) : device(dev) {}
