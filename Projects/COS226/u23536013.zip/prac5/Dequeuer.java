public class Dequeuer {
    public void dequeue() {
        // Simulate dequeuing task
        System.out.println("Dequeueing from a shared queue");
    }
}

